function search(value){

    var video=['https://www.youtube.com/embed/FtJATKMD_58',"https://www.youtube.com/embed/t18558lcvDE"]
    document.getElementById('videoframe').setAttribute('src',video[value]);
    
}

